#create code that will pass the tests in dancer_rspec file

class Dancer 
	attr_accessor :name, :age, :card

#initialize method 
	def initialize(name, age, card = [])
		puts "Initializing dancer..."
		@name = name
		@age = age.to_i
		@card = card
	end
#makes the dancer twirl and bow
	def pirouette
		p "*twirls*"
	end

	def bow
		p "*bows*"
	end

#takes the name of each dancer and adds to an array named card
	def queue_dance_with(name)
			card << name
			p card
	end

#cycles through and dances with each dancer in the array
	def begin_next_dance
		next_dance = card.delete_at(0)
		p "Now dancing with #{next_dance}."
	end

#my own code, which an rspec test was made for, that makes the dancer cartwheel
	def cartwheel
		p "*cartwheels across the stage*"
	end

end