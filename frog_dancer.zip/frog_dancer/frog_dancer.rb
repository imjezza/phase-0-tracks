#start of the class, and adds initialize method to set up what we need for each instance that is run
class Dancer
	attr_accessor :name, :age, :card

	def initialize(name, age, card = [])
		@name = name
		@age = age.to_i
		@card = card
	end

#methods added to make the dancer twirl and bow
	def pirouette
		p "*twirls*"
	end

	def bow
		p "*bows*"
	end

#first method takes name of dancer provided, and adds it to the card array
#second method takes the first name in the card array, deletes it from the array(as they have now danced), and displays a message stating theyre dancing
	def queue_dance_with(name)
		card << name
	end

	def begin_next_dance
		current_dance = card.delete_at(0)
		p "Now dancing with #{current_dance}."
	end

#method i created to add a rspec test for, that starts a square dance
	def square_dance
		p "*Does a do-si-do.*"
	end
end

#rspec is fairly straightforward to me. i remember i was able to complete this assesment fairly easily the first time, and this time it flowed very easily. tests are simple to read, and the failure feedback given when the test is run is helpful enough to solve any issues i may have to get them to work. i know that this can be much more complicated than what was seen here, and it wont always be easy to create tests or methods for tests provided, but i feel confidence in growing this skill more easily than some others i will need to master over time